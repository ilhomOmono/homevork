import React from 'react'
import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
  
    const handleLogin = async () => {
      try {
        const response = await axios.post('https://fakeapi.platzi.com/en/rest/auth-jwt/login', {
          email,
          password,
        });
        localStorage.setItem('token', response.data.token);
        toast.success('Kirish muvaffaqiyatli');
      } catch (error) {
        toast.error('Xatolik: ' + error.message);
      }
    };

  return (
    <div>
    <h2>Kirish</h2>
    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Parol" />
    <button onClick={handleLogin}>Kirish</button>
  </div>
  )
}

export default Login