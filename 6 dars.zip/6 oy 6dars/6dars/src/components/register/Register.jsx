import React from 'react'
import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';


const Register = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
  
    const handleRegister = async () => {
      try {
        const response = await axios.post('https://fakeapi.platzi.com/en/rest/auth-jwt/register', {
          email,
          password,
        });
        toast.success('Ro\'yxatdan o\'tish muvaffaqiyatli');
      } catch (error) {
        toast.error('Xatolik: ' + error.message);
      }
    };

  return (
    <div>
    <h2>Ro'yxatdan o'tish</h2>
    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Parol" />
    <button onClick={handleRegister}>Ro'yxatdan o'tish</button>
  </div>
  )
}

export default Register