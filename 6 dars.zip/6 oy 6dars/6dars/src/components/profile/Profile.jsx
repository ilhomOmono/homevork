import React from 'react'
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Profile = () => {
    const [profile, setProfile] = useState(null);
  
    useEffect(() => {
      const fetchProfile = async () => {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.get('https://fakeapi.platzi.com/en/rest/auth-jwt/profile', {
            headers: { Authorization: `Bearer ${token}` },
          });
          setProfile(response.data);
        } catch (error) {
          console.error('Xatolik:', error);
        }
      };
  
      fetchProfile();
    }, []);
  
    if (!profile) return <div>Yuklanmoqda...</div>;
  
  return (
    <div>
    <h2>Profil</h2>
    <p>Email: {profile.email}</p>
    <p>Ism: {profile.name}</p>
  </div>
  )
}

export default Profile