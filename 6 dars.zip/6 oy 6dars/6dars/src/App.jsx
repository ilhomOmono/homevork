import Login from "./components/login/Login"
import Register from "./components/register/Register"



function App() {
 

  return (
    <>
       <Register/>
       <Login/>
    </>
  )
}

export default App
